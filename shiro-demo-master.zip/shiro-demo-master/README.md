# shiro-demo
学习shiro的demo，框架是
springMVC+spring+mybatis+shiro+easyui
