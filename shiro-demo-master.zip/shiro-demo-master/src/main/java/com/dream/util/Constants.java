package com.dream.util;



public class Constants {
    public static final String CURRENT_USER = "user";
}
